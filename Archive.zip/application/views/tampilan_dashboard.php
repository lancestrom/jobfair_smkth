<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url() ?>Dashboard">
            <div class="sidebar-brand-text mx-3">BKK SMK TH</div>
        </a>

        <!-- Divider -->
        <hr class="sidebar-divider my-0">

        <!-- Nav Item - Dashboard -->
        <li class="nav-item active">
            <a class="nav-link" href="<?= base_url() ?>Dashboard">
                <i class="fas fa-school"></i>
                <span>Dashboard</span></a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">

        <!-- Heading -->
        <div class="sidebar-heading">
            Main Menu
        </div>
        <li class="nav-item">
            <a class="nav-link" href="<?= base_url() ?>Dashboard/perusahaan">
                <i class="fas fa-building"></i>
                <span>Perusahaan</span></a>
        </li>
        <hr class="sidebar-divider">
        <div class="sidebar-heading">
            Perusahaan
        </div>
        <li class="nav-item">
            <a class="nav-link" href="<?= base_url() ?>Dashboard/pelamar_perusahaan">
                <i class="fas fa-user-tie"></i>
                <span>Pelamar Perusahaan</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= base_url() ?>Dashboard/absen_pelamar">
                <i class="fas fa-user-tie"></i>
                <span>Absensi Perusahaan</span></a>
        </li>
        <hr class="sidebar-divider">
        <div class="sidebar-heading">
            Logout
        </div>
        <li class="nav-item">
            <a class="nav-link" href="<?= base_url() ?>Dashboard/logout">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span></a>
        </li>

        <!-- Nav Item - Charts -->


        <!-- Divider -->
        <hr class="sidebar-divider d-none d-md-block">

        <!-- Sidebar Toggler (Sidebar) -->
        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button>

                <!-- Topbar Search -->

                <!-- Topbar Navbar -->

            </nav>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">
                <?php $this->load->view($content) ?>
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- Footer -->
        <footer class="sticky-footer bg-warning ">
            <div class="container my-auto">
                <div class="copyright text-center text-white my-auto">
                    <h5 class="text-center font-weight-bold text-uppercase">Copyright &copy; tunas harapan</h5>

                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>